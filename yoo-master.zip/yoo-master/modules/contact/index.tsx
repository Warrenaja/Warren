import React from 'react'
import Form from './elements/form'

const Contact = () => (
  <div className='px-[5%] py-32'>
    <Form />
  </div>
)

export default Contact;
