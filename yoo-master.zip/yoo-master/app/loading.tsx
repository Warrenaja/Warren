import Loading from '@/common/components/loading'
import React from 'react'

export default function LoadingPage() {
  return (
    <>
      {Loading('h-screen')}
    </>
  )
}